/**
 * Almacena detalles de los socios del club.
 * 
 * @author (su nombre) 
 * @version (un numero de version o fecha)
 */
public class Club
{
    // Defina cualquier campo necesario aqui ...
    
    /**
     * Constructor para objetos de la clase Club
     */
    public Club()
    {
        // Inicialice los campos aqui ...
        
    }

    /**
     * Agrega un nuevo socio a la lista de socios del club.
     * @param socio El objeto de socio a ser agregado.
     */
    public void asociar(Socio socio)
    {
    }

    /**
     * @return El n�mero de socios (objetos Socio) en el club.
     */
    public int numeroDeSocios()
    {
        return 0;
    }
}
