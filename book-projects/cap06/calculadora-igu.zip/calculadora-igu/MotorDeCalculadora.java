/**
 * La parte principal de la calculadora que realiza las operaciones
 * aritm�ticas y l�gicas
 * 
 * @author Hacker T. Largebrain 
 * @version 0.1(incomplete)
 */
public class MotorDeCalculadora
{
   

    /**
     * Crea un  MotorDeCalculadora.
     */
    public MotorDeCalculadora()
    {
    }

    /**
     * @return El valor actualmente mostrado en el visor
     * de la calculadora
     */
    public int getValorEnVisor()
    {
        return 0;
    }

    /**
     * Una bot�n de n�mero fue presionado
     * @param numero el digito presionado.
     */
    public void numeroPresionado(int numero)
    {
    }

    /**
     * El boton '+' fue presionado 
     */
    public void mas()
    {
    }

    /**
     * El bot�n '-' fue presionado
     */
    public void menos()
    {
    }
    
    /**
     * El bot�n '=' fue presionado
     */
    public void igual()
    {
    }

    /**
     * El bot�n 'C' (clear-limpiar) fue presionado.
     */
    public void limpiar()
    {
    }

    /**
     * @return el t�tulo de este motor de c�lculo
     * 
     */
    public String getTitulo()
    {
        return "";
    }

    /**
     * @return El autor de este motor.
     */
    public String getAutor()
    {
        return "";
    }

    /**
     * @return El numero de version de este motor
     */
    public String getVersion()
    {
        return "";
    }
}
